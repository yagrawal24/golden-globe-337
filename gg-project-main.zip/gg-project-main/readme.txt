Files to run:
- "python3 gg_api_test.py" to get readable human output
- helper_functions.py is imported into gg_api_test.py

Human readable output
- Includeds best hosts, winners, presenters, nominees, best dressed, best joke

Packages to download:
- pip install:
    - langdetect # Install langdetect via pip
    - pandas
    - emoji
    - cairosvg
    - matplotlib
    - scikit-learn
    - rapidfuzz